#use "colwheel.ml";;
print_string "To run: main();;"; print_newline();;
